import React from "react";

export default function Teste() {
  return (
    <div>
      <h1>Page Teste</h1>
    </div>
  );
}
